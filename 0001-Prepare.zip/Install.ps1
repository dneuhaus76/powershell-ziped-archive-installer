﻿set-location $PSScriptRoot

<# --- Scheduled Tasks --- #>
#Reginal Settings - SystemLocale geht nur wenn bereits installiert
Set-WinSystemLocale -SystemLocale de-CH
Set-WinDefaultInputMethodOverride -InputTip "0807:00000807"

#Disable Scheduled Task for Windows Updates
Get-ScheduledTask -TaskName "Scheduled Start" | Disable-ScheduledTask

<# --- Policies 'gpedit' - Registry gesetzt --- #>
#Disable Updates
$myRegPath="HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU"
if (!(Test-Path Registry::$myRegPath)) { New-Item Registry::$myRegPath -Force}
Set-ItemProperty -path Registry::$myRegPath -Name "NoAutoUpdate" -Type DWord -Value 1 -Force

#PrinterRedirection
$myRegPath="HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services"
if (!(Test-Path Registry::$myRegPath)) { New-Item Registry::$myRegPath -Force}
Set-ItemProperty -path Registry::$myRegPath -Name "fDisableCpm" -Type DWord -Value 1 -Force

#Security Center
$myRegPath="HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows Defender Security Center\Notifications"
if (!(Test-Path Registry::$myRegPath)) { New-Item Registry::$myRegPath -Force}
Set-ItemProperty -path Registry::$myRegPath -Name "DisableEnhancedNotifications" -Type DWord -Value 1 -Force

#Smart Screen
$myRegPath="HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows\System"
if (!(Test-Path Registry::$myRegPath)) { New-Item Registry::$myRegPath -Force}
Set-ItemProperty -path Registry::$myRegPath -Name "EnableSmartScreen" -Type DWord -Value 0 -Force


#Disable Download/Update Windows Store Apps
#Set-ItemProperty -path Registry::"HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\WindowsStore" -Name "AutoDownload" -Type DWord -Value 2 -Force

<# --- Enable SideLoad --- #>
$myRegPath="HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\AppModelUnlock"
if (!(Test-Path Registry::$myRegPath)) { New-Item Registry::$myRegPath -Force}
Set-ItemProperty -path Registry::$myRegPath -Name "AllowAllTrustedApps" -Type DWord -Value 1 -Force

EXIT 0