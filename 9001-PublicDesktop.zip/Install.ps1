﻿set-location $PSScriptRoot

#filecopy
Copy-Item -Path .\PublicDesktop\*.* -Destination $("$env:PUBLIC\Desktop") -Force

